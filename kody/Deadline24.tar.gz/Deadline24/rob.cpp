#include<bits/stdc++.h>
#define rep(i,k,n) for(ll i= (ll) k;i< (ll) n;i++)
#define all(v) (v).begin(), (v).end()
#define SZ(v) (int)((v).size())
#define pb push_back
#define ft first
#define sd second
typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
const long long INF = 4e18L + 1;
const int IINF = 2e9 + 1;

using namespace std;

template<class TH> void _dbg(const char *sdbg, TH h){ cerr<<sdbg<<'='<<h<<endl; }
template<class TH, class... TA> void _dbg(const char *sdbg, TH h, TA... a) {
  while(*sdbg!=',')cerr<<*sdbg++;cerr<<'='<<h<<','; _dbg(sdbg+1, a...);
}

#define LOCAL
#ifdef LOCAL
#define DBG(...) _dbg(#__VA_ARGS__, __VA_ARGS__)
#else
#define DBG(...) (__VA_ARGS__)
#define cerr if(0)cout
#endif
/*
 * Jako argumenty podajemy najpierw nazwe wzorcowki a potem skrot nazwy zadania
 * (mozna tylko jedno, jak nazwy sa takie same)
 */
 
string wyjscie(string nazwa, int nr)
{
	string s = to_string(nr);
	if (SZ(s) == 1)
		nazwa += "0" + s + ".ans";
	else
		nazwa += s + ".ans";
	return nazwa;
} 
 
void rob(string wzorcowka, string zadanie, int nr)
{
	 string s = to_string(nr), z = zadanie;
	 if (SZ(s) == 1)
		z += "0" + s + ".in";
	else
		z += s + ".in";
	string sys = "./" + wzorcowka + " < " + z + " > " + wyjscie(zadanie, nr);
	system(sys.c_str());
}
 
 
int main(int argc, char** argv)
{
#ifndef LOCAL
    ios_base::sync_with_stdio(0);
    cin.tie(0);
#endif

	string wzorcowka, testy;
	if (argc == 2)
	{
		wzorcowka = string(argv[1]);
		testy = wzorcowka;
	}
	else if (argc == 3)
	{
		wzorcowka = string(argv[1]);
		testy = string(argv[2]);
	}
	else
	{
		cout << "Zla liczba argumentow!";
		return 0;
	}
	vector < int > Do_zrobienia = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	
	
	vector < thread > V;
	for(int j=0; j<SZ(Do_zrobienia); j++)
		V.push_back( thread(rob, wzorcowka, testy, Do_zrobienia[j]) );
	for(auto& el : V)
		el.join();
	string wyj = "zip -r " + testy + ".zip";
	for(auto& el : Do_zrobienia)
		wyj += " " + wyjscie(testy, el);
	system(wyj.c_str());

    return 0;
}
